
import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import wolframalpha  #pip install wolframalpha api
import datetime
#import pandas as np
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib 

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)


def speak(audio):
    engine = pyttsx3.init()
    engine.say(audio)  
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon!")   

    else:
        speak("Good Evening!")  

    speak("I am Jarvis Sir. Please tell me how may I help you")       

def takeCommand():
    #It takes microphone input from the user and returns string output
    query=input("Listening...\n enter the query: ")
    return query

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('gopalas1944@gmail.com', 'Gopaldas44*')
    server.sendmail('gopalas1944@gmail.com', to, content)
    server.close()

if __name__ == "__main__":
    wishMe()
  #  dataset = pd.read_csv('email.csv')
    server =  wolframalpha.Client('R972TX-7P436RUGU')
    q=0
    while(q!=56):
    # if 1:
        query = takeCommand().lower()

        # Logic for executing tasks based on query
        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            result_wiki = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(result_wiki)
            speak(result_wiki)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")

        elif 'open google' in query:
            webbrowser.open("google.com")

        elif 'open stackoverflow' in query:
            webbrowser.open("stackoverflow.com")   


        elif 'play music' in query:
            speak("Which kind of music do you want to here? party song, romantic song or you want me to play a song for u?")
            query1 = takeCommand().lower()
            
            if "romantic" in query1:
                music_dir = 'F:\\BILL PAYMENT\\machin\\Pc softwesr\\Motivation5\\romantic'
                songs = [f for f in listdir(music_dir) if isfile(join(music_dir,f))]
                print(songs)    
                os.startfile(os.path.join(music_dir, random.choice(songs)))
                speak("Okay, here is your music! Enjoy!")
                
            elif "party" in query1:
                music_dir = 'F:\\BILL PAYMENT\\machin\\Pc softwesr\\Motivation5\\party'
                songs = [f for f in listdir(music_dir) if isfile(join(music_dir,f))]
                
                print(songs)    
                os.startfile(os.path.join(music_dir, random.choice(songs)))
                speak("Okay, here is your music! Enjoy!")
                
            else:
                music_dir = 'F:\\BILL PAYMENT\\machin\\Pc softwesr\\Motivation5\\024'
                songs = [f for f in listdir(music_dir) if isfile(join(music_dir,f))]
                
                print(songs)    
                os.startfile(os.path.join(music_dir, random.choice(songs)))
                speak("Okay, here is your music! Enjoy!")

        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            speak("Sir, the time is: "+strTime)

        elif 'open firefox' in query:
            codePath = "C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"
            os.startfile(codePath)
        elif 'open v s code' in query:
            codePath = "F:\Microsoft VS Code\Code.exe"
            os.startfile(codePath)

        elif 'send email' in query:
            try:
                speak("What should I say in email?")
                content = takeCommand()
                to = "someron.bakuli05@gmail.com"    
                sendEmail(to, content)
                speak("Email has been sent!")
            except Exception as e:
                print(e)
        
                speak("Sorry i am unable to send the email! plese try after some time")
        elif 'send bulk email' in query:
            try:
                speak("What should I say in email?")
                content = takeCommand()
                to = "someron.bakuli05@gmail.com"    
                sendEmail(to, content)
                speak("Email has been sent!")
            except Exception as e:
                print(e)
                speak("Sorry i am unable to send the email! plese try after some time")
        
        elif 'bye' in query:
            speak("Good bye sir!")
            q=56
            
        elif 'hi ' in voice_note or 'hello' in voice_note :
            print ('In Greeting......')
            play_sound(mp3_greeting_list)
        elif 'ok google' in voice_note or 'hi google' in voice_note or 'hello google' in voice_note:
            static_speech('i am flatter, but that is not me')
            static_speech('i am your jarvis' + textbox_inputValue)

        elif 'ok siri' in voice_note or 'hi siri' in voice_note or 'hello siri' in voice_note:
            static_speech('i am flatter, but that is not me')
            static_speech('i am your jarvis' + textbox_inputValue)

        elif 'ok alexa' in voice_note or 'hi alexa' in voice_note or 'hello alexa' in voice_note:
            static_speech('i am flatter, but that is not me')
            static_speech('i am your jarvis' + textbox_inputValue)

        elif 'like you' in voice_note or 'love you' in voice_note:
            static_speech('thanks ' + textbox_inputValue)
            static_speech('you just made my day')
            
        else:
            try:
                try:
                    print("Searching....")
                    question = server.query(query)
                    output = next(question.results).text
                    speak(output)
                except:
                    speak('Searching Wikipedia...')
                    result_wiki = wikipedia.summary(query, sentences=2)
                    speak("According to Wikipedia")
                    print(result_wiki)
                    speak(result_wiki)
            except:
                webbrowser.open('www.google.com')
                speak("Sorry! I don't know the exact answer; batter you google it")
                    
              
