
import pandas as pd
dataset = pd.read_csv('wp.csv')
e = dataset.iloc[:,:1]
n = dataset.iloc[:,1:2]
a = pd.DataFrame(e).to_numpy()
b = pd.DataFrame(n).to_numpy()
idcode = list()
ide = list()
for i in range(len(n)):
    j = a[i]
    ide.append(j[0])
    j = b[i]
    idcode.append(j[0])

usr = ide[0]        #twitter
psw = idcode[0]

usre = ide[1]       #fb
paw = idcode[1]

import os
os.system("TASKKILL/F /IM Rainmeter.exe")


# twitter stsrt 
from selenium import webdriver

usr = "cajiy@smart-mail.top"
psw = "nilu1998"

driver = webdriver.Firefox(executable_path="C:\\Users\\Somerom\\Desktop\\bluethooth\\geckodriver.exe")
driver.get("https://www.twitter.com/login")

usr_box = driver.find_element_by_class_name('js-username-field')
usr_box.send_keys(usr)

psw_box = driver.find_element_by_class_name('js-password-field')
psw_box.send_keys(psw)
driver.find_element_by_class_name('submit').click()
#login_button.submit()
#finished
#fb start
from selenium import webdriver
usre = "dtcdyvdvh@gmail.com"
paw = "nilu1998"

driver = webdriver.Firefox(executable_path="C:\\Users\\Somerom\\Desktop\\bluethooth\\geckodriver.exe")
driver.get("https://www.facebook.com/")

usre_box = driver.find_element_by_id('email')
usre_box.send_keys(usre)

paw_box = driver.find_element_by_id('pass')
paw_box.send_keys(paw)

login_btn = driver.find_element_by_id('u_0_b')
login_btn = driver.find_element_by_id('u_0_2')
login_btn.submit()


#finshed

'''     IN THIS PROJECT
SMS USING TWILIO get ph no
translate
ONLINE AND OFFLINE COMMENT EDIT
CLOSE THE RAIN
SETUP BULK MAIL
WP USING SCRIPT


        OUT OF THIS PROJECT
LIVE  CRIKATE
3RD UMPARIR
CHES GAME
'''

