#import pyautogui
#wolframalpha 
#pandas
#import os
#imprt gTTs 

import requests
from bs4 import BeautifulSoup 

url = "https://www.amazon.in/dp/B07SCP1DN6/ref=sspa_dk_left_sx_aax_0?psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUjVBWTk4N1JFMDRBJmVuY3J5cHRlZElkPUEwMTI4OTQzNFJLODBXNjVKTjlRJmVuY3J5cHRlZEFkSWQ9QTA3MjUxNTkxQTBZN0I0UzhUSDQ0JndpZGdldE5hbWU9c3Bfc2VhcmNoX2xlZnRfc2hhcmVkJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ=="
haders = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebkit/537.36(KHTML, like Gecko) Chrome/75.0.3770.100  Safari/537.36'}

page = requests.get(url, headers = haders)
soup = BeautifulSoup(page.content, 'html.parser')

title = soup.find(id="productTitle").get_text()
price = soup.find(id="priceblock_ourprice").get_text()
covert_price = price[1:13]
covert_price=covert_price.replace(',','')
covert_price = float(covert_price) 
print(covert_price)
print(title.strip())



from selenium import webdriver

usr = "cajiy@smart-mail.top"
psw = "nilu1998"

driver = webdriver.Firefox(executable_path="C:\\Users\\Somerom\\Desktop\\bluethooth\\geckodriver.exe")
driver.get("https://www.twitter.com/login")
driver.implicitly_wait(1)
usr_box = driver.find_element_by_class_name('js-username-field')
usr_box.send_keys(usr)
driver.implicitly_wait(1)
psw_box = driver.find_element_by_class_name('js-password-field')
psw_box.send_keys(psw)
driver.implicitly_wait(1)
driver.find_element_by_class_name('EdgeButton--medium').submit()




#cctv
elif "open cctv" in query:
    webbrowser.open("")
    
    
    
    
    
    
    
    
from selenium import webdriver

driver = webdriver.Firefox(executable_path="C:\\Users\\Somerom\\Desktop\\bluethooth\\geckodriver.exe")
driver.get('https://web.whatsapp.com/')

name_wp = input("Please enter the resiver name : ")
speak("Would you like to manually type the message?")
df = takeCommand().lower()
if "yes" in df:
    msg_wp = input("Enter the message : ")
else:
    msg_wp = takeCommand().lower()
speak("How many time do you went to send the message")
count = int(input("Enter the count : "))


user_wp = driver.find_element_by_xpath('//span[@title = "{}"]'.format(name_wp))
user_wp.click()

msg_box = driver.find_element_by_class_name('_3u328')

for i in range(count):
    msg_box.send_keys(msg_wp)
    button = driver.find_element_by_class_name('_3M-N-')
    button.click()
    
    
    
    